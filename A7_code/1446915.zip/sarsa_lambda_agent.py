#!/usr/bin/env python

"""
  Author: Adam White, Matthew Schlegel, Mohammad M. Ajallooeian
  Purpose: for use of Rienforcement learning course University of Alberta Fall 2017
 
  agent does *no* learning, selects actions randomly from the set of legal actions
 
"""


import numpy as np
import random
import tiles3

num_tilings=8
tilings_size=8*8
memory_size=4096
alpha=0.1/num_tilings
gamma=1.0
lamda=0.9


def agent_init():
    global w_vector
    w_vector=np.zeros(num_tilings)
    return

def agent_start(this_observation): # returns 
    global w_vector,x_vector, z_vector,action
    thro_forward=np.inner(w_vector,get_x_vector(2,this_observation) )
    
    thro_reverse=np.inner(w_vector,get_x_vector(0,this_observation) )
    thro_zero=np.inner(w_vector,get_x_vector(1,this_observation) )
    if max(thro_forward,thro_reverse,thro_zero)==thro_forward:
        action=2
    elif max(thro_forward,thro_reverse,thro_zero)==thro_reverse:
        action=0
    else:
        action=1    
    
    x_vector=get_x_vector(action,this_observation)
    
    z_vector=np.zeros(len(x_vector))
    

    return action


def agent_step(reward, this_observation): # returns
    global w_vector,x_vector, z_vector,action
    delta=reward
    for i in range(len(x_vector)):
        if x_vector[i]==1:
            delta=delta-w_vector[i]
            z_vector[i]=1
            
    thro_forward=np.inner(w_vector,get_x_vector(2,this_observation) )
    thro_reverse=np.inner(w_vector,get_x_vector(0,this_observation) )
    thro_zero=np.inner(w_vector,get_x_vector(1,this_observation) )
    if max(thro_forward,thro_reverse,thro_zero)==thro_forward:
        action=2
    elif max(thro_forward,thro_reverse,thro_zero)==thro_reverse:
        action=0
    else:
        action=1
        
    x_vector=get_x_vector(action,this_observation)
    for i in range(len(x_vector)):
        if x_vector[i]==1:
            delta=delta+gamma*w_vector[i]
    w_vector=w_vector+alpha*delta*z_vector
    z_vector=gamma*lamda*z_vector
    
    
    
   
    return action

def agent_end(reward):
    global w_vector,x_vector, z_vector,action
    delta=reward
    for i in range(len(x_vector)):
        if x_vector[i]==1:
            delta=delta-w_vector[i]
            z_vector[i]=1
    w_vector=w_vector+alpha*delta*z_vector
    
    
 
    return

def agent_cleanup():
    # clean up
    return

def agent_message(inMessage): # returns string, inMessage: string
    # might be useful to get information from the agent

    if inMessage == "what is your name?":
        return "my name is skeleton_agent!"
    elif inMessage == "Op value involve":
        
        return 
  
    # else
    return "I don't know how to respond to your message"

def get_x_vector(action_value,state):#return tile with respect to input action value
    iht=tiles3.IHT(memory_size)
    a=tiles3.tiles(iht,num_tilings,[8*state[0]/(0.5+1.2),8*state[1]/(0.07+0.07)] ,[action_value],False)
    
    return a

